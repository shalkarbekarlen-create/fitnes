USE fitness_club_db;

-- CASE: classify membership plans by price
SELECT type_name, price,
  CASE
    WHEN price < 20000 THEN 'Budget'
    WHEN price <= 70000 THEN 'Standard'
    ELSE 'Premium'
  END AS price_category
FROM membership_types;

-- CASE: classify member activity using visit counts
SELECT m.member_id, m.first_name, m.last_name,
       COUNT(a.attendance_id) AS visits,
       CASE
         WHEN COUNT(a.attendance_id) >= 3 THEN 'High activity'
         WHEN COUNT(a.attendance_id) >= 1 THEN 'Medium activity'
         ELSE 'No recorded visits'
       END AS activity_level
FROM members m
LEFT JOIN attendance a ON m.member_id = a.member_id
GROUP BY m.member_id, m.first_name, m.last_name;

-- UPDATE example (safe demonstration: adjust one plan price)
-- Uncomment to apply:
-- UPDATE membership_types SET price = 26000 WHERE type_name = 'Monthly';

-- DELETE example (delete a cancelled registration by its ID)
-- Uncomment and replace 9999 with an existing registration_id:
-- DELETE FROM class_registrations WHERE registration_id = 9999 AND status = 'cancelled';

-- DDL example: add an emergency contact column
-- Uncomment to apply once:
-- ALTER TABLE members ADD COLUMN emergency_contact VARCHAR(30) NULL;

-- DROP example: remove a temporary table if it exists
DROP TABLE IF EXISTS temp_query_demo;
