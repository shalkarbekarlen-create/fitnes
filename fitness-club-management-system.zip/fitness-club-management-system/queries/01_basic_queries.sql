USE fitness_club_db;

-- 1. Display all members
SELECT * FROM members;

-- 2. Display all branches
SELECT * FROM branches;

-- 3. Show membership plans from lowest to highest price
SELECT type_name, duration_days, price
FROM membership_types
ORDER BY price ASC;

-- 4. Show active trainers
SELECT trainer_id, first_name, last_name, specialization
FROM trainers
WHERE status = 'active';

-- 5. Show upcoming group classes
SELECT class_name, class_datetime, capacity
FROM group_classes
ORDER BY class_datetime;
