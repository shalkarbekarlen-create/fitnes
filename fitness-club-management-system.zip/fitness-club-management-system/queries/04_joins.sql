USE fitness_club_db;

-- 1. Members and their home branches
SELECT m.member_id, m.first_name, m.last_name, b.branch_name
FROM members m
JOIN branches b ON m.branch_id = b.branch_id;

-- 2. Memberships with member and plan information
SELECT m.first_name, m.last_name, mt.type_name, ms.start_date, ms.end_date, ms.status
FROM memberships ms
JOIN members m ON ms.member_id = m.member_id
JOIN membership_types mt ON ms.membership_type_id = mt.membership_type_id;

-- 3. Group classes with trainer and workout details
SELECT gc.class_name, gc.class_datetime,
       CONCAT(t.first_name, ' ', t.last_name) AS trainer,
       w.workout_name
FROM group_classes gc
JOIN trainers t ON gc.trainer_id = t.trainer_id
JOIN workouts w ON gc.workout_id = w.workout_id;

-- 4. Registrations with member names and class names
SELECT cr.registration_id, CONCAT(m.first_name, ' ', m.last_name) AS member,
       gc.class_name, cr.status
FROM class_registrations cr
JOIN members m ON cr.member_id = m.member_id
JOIN group_classes gc ON cr.class_id = gc.class_id;

-- 5. Personal training sessions with trainer and member names
SELECT pt.session_datetime,
       CONCAT(m.first_name, ' ', m.last_name) AS member,
       CONCAT(t.first_name, ' ', t.last_name) AS trainer,
       pt.duration_minutes, pt.session_status, pt.price
FROM personal_training pt
JOIN members m ON pt.member_id = m.member_id
JOIN trainers t ON pt.trainer_id = t.trainer_id;

-- 6. Include members even if they have no attendance records
SELECT m.member_id, m.first_name, m.last_name, COUNT(a.attendance_id) AS visits
FROM members m
LEFT JOIN attendance a ON m.member_id = a.member_id
GROUP BY m.member_id, m.first_name, m.last_name
ORDER BY visits DESC;
