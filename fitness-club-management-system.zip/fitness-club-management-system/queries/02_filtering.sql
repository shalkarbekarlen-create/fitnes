USE fitness_club_db;

-- 1. Members who are currently marked active
SELECT *
FROM members
WHERE status = 'active';

-- 2. Membership plans costing between 20,000 and 100,000
SELECT *
FROM membership_types
WHERE price BETWEEN 20000 AND 100000;

-- 3. Members whose first name begins with 'A'
SELECT *
FROM members
WHERE first_name LIKE 'A%';

-- 4. Payments made using a card
SELECT *
FROM membership_payments
WHERE payment_method = 'card';

-- 5. Attendance records during May 2025
SELECT *
FROM attendance
WHERE check_in >= '2025-05-01'
  AND check_in < '2025-06-01';

-- 6. Members with a missing phone number
SELECT *
FROM members
WHERE phone IS NULL;
