USE fitness_club_db;

-- 1. Membership revenue by month
SELECT DATE_FORMAT(payment_date, '%Y-%m') AS revenue_month,
       SUM(amount) AS membership_revenue
FROM membership_payments
WHERE payment_status = 'paid'
GROUP BY DATE_FORMAT(payment_date, '%Y-%m')
ORDER BY revenue_month;

-- 2. Total paid revenue from memberships and additional services
SELECT
  (SELECT COALESCE(SUM(amount),0)
   FROM membership_payments WHERE payment_status='paid')
  +
  (SELECT COALESCE(SUM(total_amount),0)
   FROM service_payments WHERE payment_status='paid') AS total_revenue;

-- 3. Trainer workload in hours (completed personal training)
SELECT t.trainer_id, CONCAT(t.first_name, ' ', t.last_name) AS trainer,
       ROUND(SUM(pt.duration_minutes)/60,2) AS completed_training_hours,
       COUNT(pt.session_id) AS completed_sessions
FROM trainers t
LEFT JOIN personal_training pt
  ON t.trainer_id = pt.trainer_id AND pt.session_status = 'completed'
GROUP BY t.trainer_id, t.first_name, t.last_name
ORDER BY completed_training_hours DESC;

-- 4. Most active members by recorded visits
SELECT m.member_id, CONCAT(m.first_name, ' ', m.last_name) AS member,
       COUNT(a.attendance_id) AS visits
FROM members m
JOIN attendance a ON m.member_id = a.member_id
GROUP BY m.member_id, m.first_name, m.last_name
ORDER BY visits DESC
LIMIT 10;

-- 5. Membership plans ranked by number sold
SELECT mt.type_name, COUNT(ms.membership_id) AS memberships_sold
FROM membership_types mt
LEFT JOIN memberships ms ON mt.membership_type_id = ms.membership_type_id
GROUP BY mt.membership_type_id, mt.type_name
ORDER BY memberships_sold DESC;

-- 6. Group class occupancy
SELECT gc.class_id, gc.class_name, gc.capacity,
       COUNT(CASE WHEN cr.status IN ('registered','attended') THEN 1 END) AS booked_places,
       ROUND(100 * COUNT(CASE WHEN cr.status IN ('registered','attended') THEN 1 END)
             / gc.capacity, 1) AS occupancy_percent
FROM group_classes gc
LEFT JOIN class_registrations cr ON gc.class_id = cr.class_id
GROUP BY gc.class_id, gc.class_name, gc.capacity
ORDER BY occupancy_percent DESC;

-- 7. Memberships expiring within the next 30 days
SELECT m.first_name, m.last_name, ms.end_date
FROM memberships ms
JOIN members m ON ms.member_id = m.member_id
WHERE ms.status = 'active'
  AND ms.end_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
ORDER BY ms.end_date;

-- 8. Revenue by club branch (membership revenue attributed to member's branch)
SELECT b.branch_name, SUM(mp.amount) AS paid_membership_revenue
FROM branches b
JOIN members m ON b.branch_id = m.branch_id
JOIN memberships ms ON m.member_id = ms.member_id
JOIN membership_payments mp ON ms.membership_id = mp.membership_id
WHERE mp.payment_status = 'paid'
GROUP BY b.branch_id, b.branch_name
ORDER BY paid_membership_revenue DESC;
