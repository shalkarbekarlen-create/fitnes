USE fitness_club_db;

-- 1. Number of members by status
SELECT status, COUNT(*) AS member_count
FROM members
GROUP BY status;

-- 2. Average and maximum membership price
SELECT AVG(price) AS average_price, MAX(price) AS maximum_price
FROM membership_types;

-- 3. Total paid membership revenue
SELECT SUM(amount) AS membership_revenue
FROM membership_payments
WHERE payment_status = 'paid';

-- 4. Number of visits by member
SELECT member_id, COUNT(*) AS visit_count
FROM attendance
GROUP BY member_id
ORDER BY visit_count DESC;

-- 5. Trainers with at least one personal-training session
SELECT trainer_id, COUNT(*) AS session_count
FROM personal_training
GROUP BY trainer_id
HAVING COUNT(*) >= 1;

-- 6. Revenue by payment method
SELECT payment_method, SUM(amount) AS total_amount
FROM membership_payments
WHERE payment_status = 'paid'
GROUP BY payment_method
ORDER BY total_amount DESC;
