# Query Results

Run the SQL files in `queries/` in MySQL Workbench and save screenshots or exported result grids here.

Suggested screenshots:
- `01_members_and_branches.png` — basic SELECT and JOIN output
- `02_membership_revenue.png` — aggregation / revenue result
- `03_trainer_workload.png` — trainer workload analysis
- `04_member_activity.png` — attendance analysis
- `05_class_occupancy.png` — group-class occupancy

These screenshots are intentionally left for results generated from your own MySQL execution environment.
