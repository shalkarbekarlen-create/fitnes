# Analysis Summary

## What the sample data demonstrates
The repository contains fictional sample records across three branches, eight members, four trainers, four membership plans, and operational records for classes, attendance, personal training, services, and payments.

## Business analysis included
1. **Membership revenue:** monthly paid revenue and payment-method breakdown.
2. **Trainer workload:** completed personal-training minutes converted to hours.
3. **Member activity:** visits per member, ranked from highest to lowest.
4. **Plan popularity:** number of subscriptions associated with each membership plan.
5. **Class occupancy:** registered and attended places compared with class capacity.
6. **Membership retention:** active memberships expiring within the next 30 days.

## Interpretation
- Revenue should be calculated from records whose payment status is `paid`; pending and refunded transactions are excluded.
- Trainer workload in the provided query counts completed personal-training sessions. Group-class teaching time can be analyzed separately if required.
- Attendance is the operational source for member visit activity.
- Class occupancy uses registrations with status `registered` or `attended`; cancelled and no-show records are not counted as booked places.

## Limitations
- The sample dataset is small and fictional; it demonstrates query logic rather than real club performance.
- Membership expiry queries depend on the current date at execution time.
- The model records membership payments and service payments separately. Personal-training session prices are stored on the session record and are not included in the payment revenue query because no separate personal-training payment table is part of the case's 15-table scope.
