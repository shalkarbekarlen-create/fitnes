# Fitness Club Management System

**Case 13 — Fitness Club Management System**  
Database project built with **MySQL 8.0**.

## Project overview
This database supports a modern fitness and spa center. It stores members, branches, trainers, membership plans and sales, group classes, class registrations, attendance, personal training, services, payments, and employees.

## Repository structure
```text
fitness-club-management-system/
├── README.md
├── docs/
│   ├── project_brief.md
│   ├── database_documentation.md
│   ├── erd.png
│   └── final_report.pdf
├── database/
│   ├── 01_create_tables.sql
│   ├── 02_insert_data.sql
│   └── 03_constraints.sql
├── queries/
│   ├── 01_basic_queries.sql
│   ├── 02_filtering.sql
│   ├── 03_aggregation.sql
│   ├── 04_joins.sql
│   ├── 05_case_update_delete.sql
│   └── 06_business_analysis.sql
├── results/
│   ├── query_results/
│   └── analysis_summary.md
└── presentation/
    └── final_presentation.pdf
```

## Requirements
- MySQL Server 8.0 or later
- MySQL Workbench (recommended) or another MySQL client

## How to run
Run the SQL files in this order:
1. `database/01_create_tables.sql`
2. `database/02_insert_data.sql`
3. `database/03_constraints.sql`
4. Execute query files in the `queries/` directory as needed.

Open MySQL Workbench, connect to your server, open each `.sql` file, and click the lightning-bolt **Execute** button.

## Main business processes
- Sell memberships and track expiration dates.
- Register members for group classes.
- Assign trainers for personal training.
- Record member check-ins and attendance.
- Track membership and service payments.
- Analyze revenue, trainer workload, and member activity.

## Database tables
The database contains 15 core tables:
`branches`, `members`, `trainers`, `membership_types`, `memberships`,
`membership_payments`, `workout_types`, `workouts`, `group_classes`,
`class_registrations`, `attendance`, `personal_training`, `services`,
`service_payments`, and `employees`.

## Notes
- The schema uses InnoDB and `utf8mb4`.
- Monetary values use `DECIMAL(10,2)`.
- Dates are stored using `DATE`, and event timestamps use `DATETIME`.
- The sample dataset is fictional and intended for educational use.
