USE fitness_club_db;

INSERT INTO branches (branch_name,address,phone,opened_date) VALUES
('Central Fitness','12 Abay Avenue, Almaty','+7 700 111 22 33','2021-03-01'),
('Dostyk Fitness','45 Dostyk Street, Almaty','+7 700 222 33 44','2022-06-15'),
('Taraz Fitness','8 Tole Bi Street, Taraz','+7 700 333 44 55','2023-01-10');

INSERT INTO members (branch_id,first_name,last_name,email,phone,birth_date,join_date,status) VALUES
(1,'Ayan','Saparov','ayan.saparov@example.com','+7 701 100 00 01','2001-04-12','2025-01-10','active'),
(1,'Aruzhan','Bekova','aruzhan.bekova@example.com','+7 701 100 00 02','1999-09-23','2025-02-03','active'),
(2,'Dias','Nurgali','dias.nurgali@example.com','+7 701 100 00 03','1998-01-17','2024-11-20','active'),
(2,'Madina','Omarova','madina.omarova@example.com','+7 701 100 00 04','2002-07-05','2025-03-15','inactive'),
(3,'Alikhan','Tulegen','alikhan.tulegen@example.com','+7 701 100 00 05','2000-12-30','2025-04-01','active'),
(3,'Dana','Kassym','dana.kassym@example.com','+7 701 100 00 06','1997-05-19','2024-12-12','active'),
(1,'Nursultan','Aliyev','nursultan.aliyev@example.com','+7 701 100 00 07','1996-03-08','2025-05-11','active'),
(2,'Aigerim','Serik','aigerim.serik@example.com','+7 701 100 00 08','2003-11-14','2025-05-20','blocked');

INSERT INTO trainers (branch_id,first_name,last_name,specialization,hire_date,hourly_rate,status) VALUES
(1,'Timur','Askarov','Strength training','2022-02-01',9000,'active'),
(2,'Laura','Kim','Yoga and Pilates','2023-04-10',8500,'active'),
(3,'Ruslan','Akhmetov','CrossFit','2021-09-15',10000,'active'),
(1,'Amina','Baur','Cardio','2024-01-20',8000,'active');

INSERT INTO membership_types (type_name,duration_days,price,description) VALUES
('Monthly',30,25000,'Access for one month'),
('Quarterly',90,65000,'Access for three months'),
('Annual',365,220000,'Access for one year'),
('Student',30,18000,'Discounted monthly plan');

INSERT INTO memberships (member_id,membership_type_id,start_date,end_date,status) VALUES
(1,1,'2025-01-10','2025-02-09','expired'),
(1,2,'2025-03-01','2025-05-29','expired'),
(2,3,'2025-02-03','2026-02-03','active'),
(3,1,'2025-04-01','2025-05-01','expired'),
(4,4,'2025-03-15','2025-04-14','expired'),
(5,2,'2025-04-01','2025-06-30','expired'),
(6,1,'2025-05-01','2025-05-31','expired'),
(7,3,'2025-05-11','2026-05-11','active'),
(8,1,'2025-05-20','2025-06-19','cancelled');

INSERT INTO membership_payments (membership_id,payment_date,amount,payment_method,payment_status) VALUES
(1,'2025-01-10 10:15:00',25000,'card','paid'),
(2,'2025-03-01 11:20:00',65000,'online','paid'),
(3,'2025-02-03 09:30:00',220000,'card','paid'),
(4,'2025-04-01 12:00:00',25000,'cash','paid'),
(5,'2025-03-15 15:10:00',18000,'card','paid'),
(6,'2025-04-01 08:45:00',65000,'bank_transfer','paid'),
(7,'2025-05-01 13:25:00',25000,'cash','pending'),
(8,'2025-05-11 10:00:00',220000,'online','paid');

INSERT INTO workout_types (type_name,description) VALUES
('Strength','Resistance and strength exercises'),
('Cardio','Heart and endurance training'),
('Mind-body','Yoga, stretching and Pilates'),
('Functional','Functional fitness and CrossFit');

INSERT INTO workouts (workout_type_id,workout_name,difficulty,duration_minutes) VALUES
(1,'Full Body Strength','intermediate',60),
(2,'Cardio Blast','beginner',45),
(3,'Morning Yoga','beginner',60),
(4,'CrossFit Circuit','advanced',50),
(1,'Power Training','advanced',75);

INSERT INTO group_classes (branch_id,trainer_id,workout_id,class_name,class_datetime,capacity) VALUES
(1,1,1,'Strength Basics','2025-06-02 18:00:00',15),
(2,2,3,'Morning Yoga','2025-06-03 09:00:00',20),
(3,3,4,'CrossFit Challenge','2025-06-03 19:00:00',12),
(1,4,2,'Cardio Blast','2025-06-04 18:30:00',18),
(2,2,3,'Evening Pilates','2025-06-05 19:00:00',16);

INSERT INTO class_registrations (class_id,member_id,registration_date,status) VALUES
(1,1,'2025-05-25 10:00:00','registered'),
(1,2,'2025-05-25 10:05:00','attended'),
(2,3,'2025-05-26 11:00:00','attended'),
(2,4,'2025-05-26 11:10:00','registered'),
(3,5,'2025-05-27 12:00:00','registered'),
(3,6,'2025-05-27 12:10:00','attended'),
(4,7,'2025-05-28 13:00:00','registered'),
(5,8,'2025-05-29 14:00:00','cancelled');

INSERT INTO attendance (member_id,branch_id,check_in,check_out,entry_method) VALUES
(1,1,'2025-05-01 08:05:00','2025-05-01 09:20:00','turnstile'),
(1,1,'2025-05-03 08:10:00','2025-05-03 09:30:00','turnstile'),
(2,1,'2025-05-02 17:00:00','2025-05-02 18:30:00','mobile_app'),
(2,1,'2025-05-04 17:15:00','2025-05-04 18:40:00','turnstile'),
(3,2,'2025-05-05 09:00:00','2025-05-05 10:15:00','reception'),
(3,2,'2025-05-07 09:05:00','2025-05-07 10:20:00','turnstile'),
(5,3,'2025-05-08 18:00:00','2025-05-08 19:30:00','turnstile'),
(6,3,'2025-05-09 07:30:00','2025-05-09 08:45:00','turnstile'),
(7,1,'2025-05-10 18:30:00','2025-05-10 20:00:00','mobile_app'),
(7,1,'2025-05-12 18:35:00','2025-05-12 20:05:00','turnstile');

INSERT INTO personal_training (member_id,trainer_id,session_datetime,duration_minutes,session_status,price) VALUES
(1,1,'2025-05-02 10:00:00',60,'completed',12000),
(2,4,'2025-05-03 11:00:00',60,'completed',11000),
(3,2,'2025-05-04 12:00:00',45,'completed',9000),
(5,3,'2025-05-05 16:00:00',60,'scheduled',13000),
(7,1,'2025-05-06 17:00:00',60,'completed',12000);

INSERT INTO services (service_name,service_category,price,is_active) VALUES
('Sauna','Spa',5000,TRUE),
('Sports Massage','Recovery',12000,TRUE),
('Protein Shake','Nutrition',1800,TRUE),
('Swimming Pool','Aquatics',3000,TRUE);

INSERT INTO service_payments (member_id,service_id,payment_date,quantity,total_amount,payment_method,payment_status) VALUES
(1,1,'2025-05-02 11:30:00',1,5000,'card','paid'),
(2,2,'2025-05-04 12:30:00',1,12000,'online','paid'),
(3,3,'2025-05-05 10:00:00',2,3600,'cash','paid'),
(5,4,'2025-05-08 19:00:00',1,3000,'card','paid'),
(7,1,'2025-05-10 20:10:00',1,5000,'cash','pending');

INSERT INTO employees (branch_id,first_name,last_name,job_title,hire_date,salary,status) VALUES
(1,'Murat','Ibrayev','Administrator','2021-03-10',280000,'active'),
(2,'Aliya','Zhaksylyk','Receptionist','2022-07-01',220000,'active'),
(3,'Serik','Bektas','Manager','2023-02-01',350000,'active'),
(1,'Zarina','Kairat','Accountant','2024-05-15',260000,'active');
