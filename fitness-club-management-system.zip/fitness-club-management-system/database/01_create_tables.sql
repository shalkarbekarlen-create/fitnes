CREATE DATABASE IF NOT EXISTS fitness_club_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE fitness_club_db;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS service_payments, services, personal_training, attendance,
  class_registrations, group_classes, workouts, workout_types, membership_payments,
  memberships, membership_types, employees, trainers, members, branches;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE branches (
  branch_id INT AUTO_INCREMENT PRIMARY KEY,
  branch_name VARCHAR(100) NOT NULL,
  address VARCHAR(255) NOT NULL,
  phone VARCHAR(30),
  opened_date DATE
) ENGINE=InnoDB;

CREATE TABLE members (
  member_id INT AUTO_INCREMENT PRIMARY KEY,
  branch_id INT NOT NULL,
  first_name VARCHAR(60) NOT NULL,
  last_name VARCHAR(60) NOT NULL,
  email VARCHAR(120) NOT NULL,
  phone VARCHAR(30),
  birth_date DATE,
  join_date DATE NOT NULL,
  status ENUM('active','inactive','blocked') NOT NULL DEFAULT 'active',
  CONSTRAINT fk_members_branch FOREIGN KEY (branch_id) REFERENCES branches(branch_id)
) ENGINE=InnoDB;

CREATE TABLE trainers (
  trainer_id INT AUTO_INCREMENT PRIMARY KEY,
  branch_id INT NOT NULL,
  first_name VARCHAR(60) NOT NULL,
  last_name VARCHAR(60) NOT NULL,
  specialization VARCHAR(100),
  hire_date DATE NOT NULL,
  hourly_rate DECIMAL(10,2) NOT NULL,
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  CONSTRAINT fk_trainers_branch FOREIGN KEY (branch_id) REFERENCES branches(branch_id)
) ENGINE=InnoDB;

CREATE TABLE membership_types (
  membership_type_id INT AUTO_INCREMENT PRIMARY KEY,
  type_name VARCHAR(80) NOT NULL,
  duration_days INT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  description VARCHAR(255)
) ENGINE=InnoDB;

CREATE TABLE memberships (
  membership_id INT AUTO_INCREMENT PRIMARY KEY,
  member_id INT NOT NULL,
  membership_type_id INT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status ENUM('active','expired','cancelled','pending') NOT NULL DEFAULT 'pending',
  CONSTRAINT fk_memberships_member FOREIGN KEY (member_id) REFERENCES members(member_id),
  CONSTRAINT fk_memberships_type FOREIGN KEY (membership_type_id) REFERENCES membership_types(membership_type_id)
) ENGINE=InnoDB;

CREATE TABLE membership_payments (
  payment_id INT AUTO_INCREMENT PRIMARY KEY,
  membership_id INT NOT NULL,
  payment_date DATETIME NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  payment_method ENUM('cash','card','bank_transfer','online') NOT NULL,
  payment_status ENUM('paid','pending','refunded') NOT NULL DEFAULT 'paid',
  CONSTRAINT fk_mpay_membership FOREIGN KEY (membership_id) REFERENCES memberships(membership_id)
) ENGINE=InnoDB;

CREATE TABLE workout_types (
  workout_type_id INT AUTO_INCREMENT PRIMARY KEY,
  type_name VARCHAR(80) NOT NULL,
  description VARCHAR(255)
) ENGINE=InnoDB;

CREATE TABLE workouts (
  workout_id INT AUTO_INCREMENT PRIMARY KEY,
  workout_type_id INT NOT NULL,
  workout_name VARCHAR(100) NOT NULL,
  difficulty ENUM('beginner','intermediate','advanced') NOT NULL,
  duration_minutes INT NOT NULL,
  CONSTRAINT fk_workouts_type FOREIGN KEY (workout_type_id) REFERENCES workout_types(workout_type_id)
) ENGINE=InnoDB;

CREATE TABLE group_classes (
  class_id INT AUTO_INCREMENT PRIMARY KEY,
  branch_id INT NOT NULL,
  trainer_id INT NOT NULL,
  workout_id INT NOT NULL,
  class_name VARCHAR(100) NOT NULL,
  class_datetime DATETIME NOT NULL,
  capacity INT NOT NULL,
  CONSTRAINT fk_classes_branch FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
  CONSTRAINT fk_classes_trainer FOREIGN KEY (trainer_id) REFERENCES trainers(trainer_id),
  CONSTRAINT fk_classes_workout FOREIGN KEY (workout_id) REFERENCES workouts(workout_id)
) ENGINE=InnoDB;

CREATE TABLE class_registrations (
  registration_id INT AUTO_INCREMENT PRIMARY KEY,
  class_id INT NOT NULL,
  member_id INT NOT NULL,
  registration_date DATETIME NOT NULL,
  status ENUM('registered','attended','cancelled','no_show') NOT NULL DEFAULT 'registered',
  CONSTRAINT fk_reg_class FOREIGN KEY (class_id) REFERENCES group_classes(class_id),
  CONSTRAINT fk_reg_member FOREIGN KEY (member_id) REFERENCES members(member_id)
) ENGINE=InnoDB;

CREATE TABLE attendance (
  attendance_id INT AUTO_INCREMENT PRIMARY KEY,
  member_id INT NOT NULL,
  branch_id INT NOT NULL,
  check_in DATETIME NOT NULL,
  check_out DATETIME NULL,
  entry_method ENUM('turnstile','reception','mobile_app') NOT NULL DEFAULT 'turnstile',
  CONSTRAINT fk_att_member FOREIGN KEY (member_id) REFERENCES members(member_id),
  CONSTRAINT fk_att_branch FOREIGN KEY (branch_id) REFERENCES branches(branch_id)
) ENGINE=InnoDB;

CREATE TABLE personal_training (
  session_id INT AUTO_INCREMENT PRIMARY KEY,
  member_id INT NOT NULL,
  trainer_id INT NOT NULL,
  session_datetime DATETIME NOT NULL,
  duration_minutes INT NOT NULL,
  session_status ENUM('scheduled','completed','cancelled') NOT NULL DEFAULT 'scheduled',
  price DECIMAL(10,2) NOT NULL,
  CONSTRAINT fk_pt_member FOREIGN KEY (member_id) REFERENCES members(member_id),
  CONSTRAINT fk_pt_trainer FOREIGN KEY (trainer_id) REFERENCES trainers(trainer_id)
) ENGINE=InnoDB;

CREATE TABLE services (
  service_id INT AUTO_INCREMENT PRIMARY KEY,
  service_name VARCHAR(100) NOT NULL,
  service_category VARCHAR(80) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE
) ENGINE=InnoDB;

CREATE TABLE service_payments (
  service_payment_id INT AUTO_INCREMENT PRIMARY KEY,
  member_id INT NOT NULL,
  service_id INT NOT NULL,
  payment_date DATETIME NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  total_amount DECIMAL(10,2) NOT NULL,
  payment_method ENUM('cash','card','bank_transfer','online') NOT NULL,
  payment_status ENUM('paid','pending','refunded') NOT NULL DEFAULT 'paid',
  CONSTRAINT fk_spay_member FOREIGN KEY (member_id) REFERENCES members(member_id),
  CONSTRAINT fk_spay_service FOREIGN KEY (service_id) REFERENCES services(service_id)
) ENGINE=InnoDB;

CREATE TABLE employees (
  employee_id INT AUTO_INCREMENT PRIMARY KEY,
  branch_id INT NOT NULL,
  first_name VARCHAR(60) NOT NULL,
  last_name VARCHAR(60) NOT NULL,
  job_title VARCHAR(80) NOT NULL,
  hire_date DATE NOT NULL,
  salary DECIMAL(10,2) NOT NULL,
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  CONSTRAINT fk_employees_branch FOREIGN KEY (branch_id) REFERENCES branches(branch_id)
) ENGINE=InnoDB;
