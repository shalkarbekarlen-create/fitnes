USE fitness_club_db;

-- Run this file once after creating tables and inserting the sample data.
ALTER TABLE members
  ADD CONSTRAINT uq_members_email UNIQUE (email);

ALTER TABLE membership_types
  ADD CONSTRAINT uq_membership_type_name UNIQUE (type_name);

ALTER TABLE workout_types
  ADD CONSTRAINT uq_workout_type_name UNIQUE (type_name);

ALTER TABLE services
  ADD CONSTRAINT uq_service_name UNIQUE (service_name);

ALTER TABLE memberships
  ADD CONSTRAINT chk_membership_dates CHECK (end_date >= start_date);

ALTER TABLE membership_types
  ADD CONSTRAINT chk_membership_duration CHECK (duration_days > 0),
  ADD CONSTRAINT chk_membership_price CHECK (price >= 0);

ALTER TABLE trainers
  ADD CONSTRAINT chk_trainer_rate CHECK (hourly_rate >= 0);

ALTER TABLE group_classes
  ADD CONSTRAINT chk_class_capacity CHECK (capacity > 0);

ALTER TABLE workouts
  ADD CONSTRAINT chk_workout_duration CHECK (duration_minutes > 0);

ALTER TABLE personal_training
  ADD CONSTRAINT chk_pt_duration CHECK (duration_minutes > 0),
  ADD CONSTRAINT chk_pt_price CHECK (price >= 0);

ALTER TABLE services
  ADD CONSTRAINT chk_service_price CHECK (price >= 0);

ALTER TABLE service_payments
  ADD CONSTRAINT chk_service_quantity CHECK (quantity > 0),
  ADD CONSTRAINT chk_service_total CHECK (total_amount >= 0);
