# Submission Checklist

- [ ] Create a public or private GitHub repository named `fitness-club-management-system`.
- [ ] Upload the complete project folder.
- [ ] Run the three database scripts in order in MySQL Workbench.
- [ ] Execute the six query files and check the output.
- [ ] Add screenshots of actual query results to `results/query_results/`.
- [ ] Review the final report and presentation before submission.
