# Project Brief — Fitness Club Management System

## Case
**Case 13: Fitness Club Management System**

## Business context
A modern fitness and spa center needs a centralized database to manage its members, branches, trainers, memberships, classes, attendance, personal training sessions, services, employees, and payments.

## Problem statement
When information is stored separately, it becomes difficult to monitor membership expiry, class capacity, trainer workload, member attendance, and revenue. The proposed relational database provides a consistent place to store and query this information.

## Project objectives
1. Store member and employee information.
2. Manage branches, trainers, workout types, and group classes.
3. Sell membership plans and monitor their validity.
4. Record class registrations and attendance.
5. Track personal training and additional services.
6. Analyze revenue and operational activity with SQL.

## Scope
The project covers 15 related tables and sample SQL data. It includes database creation, constraints, CRUD examples, joins, aggregation, conditional logic, and business-analysis queries.

## Main users
- Administrator: manages reference data and employees.
- Receptionist: registers members, sells memberships, and records payments.
- Trainer: views assigned sessions and class schedules.
- Manager: reviews revenue and activity reports.

## Key analytical questions
- How much revenue was received from memberships?
- Which trainers have the highest session workload?
- Which members visit the club most frequently?
- Which membership plans are most popular?
- Which group classes have the highest registration levels?
