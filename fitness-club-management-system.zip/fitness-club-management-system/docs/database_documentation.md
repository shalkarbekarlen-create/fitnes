# Database Documentation

## DBMS
MySQL 8.0+, InnoDB storage engine, `utf8mb4` character set.

## Table catalogue

| Table | Purpose |
|---|---|
| branches | Fitness club locations |
| members | Registered club members |
| trainers | Trainers and their specializations |
| membership_types | Membership plan catalogue |
| memberships | Member subscriptions and validity periods |
| membership_payments | Payments for memberships |
| workout_types | Exercise / workout categories |
| workouts | Workout definitions |
| group_classes | Scheduled group classes |
| class_registrations | Member registrations for classes |
| attendance | Member check-in and check-out records |
| personal_training | One-to-one training sessions |
| services | Additional spa and fitness services |
| service_payments | Payments for additional services |
| employees | Non-trainer club employees |

## Relationships
- One branch can have many members, trainers, and employees.
- One member can have many memberships, class registrations, attendance records, personal-training sessions, and service payments.
- One membership type can be used by many memberships.
- One membership can have many membership payments.
- One trainer can conduct many group classes and personal-training sessions.
- One workout type can classify many workouts.
- One group class can have many registrations.
- One service can appear in many service-payment records.

## Important design decisions
- Each table has a numeric primary key.
- Foreign keys preserve referential integrity.
- `DECIMAL(10,2)` is used for monetary values.
- Membership start and end dates are stored separately to support expiry checks.
- Attendance stores both check-in and optional check-out timestamps.
- The sample design treats membership payments and additional service payments as separate transaction types.

## Implementation order
Create tables first, insert sample data second, then apply additional constraints. Run the business query files after loading the sample data.
